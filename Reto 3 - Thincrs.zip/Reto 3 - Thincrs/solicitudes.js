let container = document.getElementById('container')
let myButtonPokeOne = document.createElement('Ditto')
let myButtonPokeTwo = document.createElement('Eevee')
let myButtonPokeThree = document.createElement('Squirtle')

const buttonStyle = 'background-color: #4CAF50; border: 2px, color:black; background-color: #e7e7e7; color: black; padding: 28px; font-size: 16px; margin-right: 1em; margin-top: 1em'
const titleStyle = 'font-size: 24px; font-weight: 500; letter-spacing: 2px; line-height: 3em; padding-left: 0.25em; color: black; padding-bottom: 1em'

const test = () => {
    return new Promise((resolve, reject) => {
        const url = 'https://pokeapi.co/api/v2/pokemon/'
        axios
            .get(url)
            .then((res) => resolve(res.data))
            .catch((err) => reject(err))
    })
}

  
test()
    .then(res => {
        console.log('res', res)
        const myH1 = document.createElement('h1')
        myH1.innerHTML = 'Mis pokémon favoritos'
        myH1.style = titleStyle
        container.append(myH1)
       
        myButtonPokeOne = document.createElement('btnDitto')
        myButtonPokeOne.innerHTML = 'Ditto '
        myButtonPokeOne.style = buttonStyle
        container.append(myButtonPokeOne)

        myButtonPokeTwo = document.createElement('btnEevee')
        myButtonPokeTwo.innerHTML = 'Eevee '
        myButtonPokeTwo.style = buttonStyle
        container.append(myButtonPokeTwo)

        myButtonPokeThree = document.createElement('btnSquirtle')
        myButtonPokeThree.innerHTML = 'Squirtle '
        myButtonPokeThree.style = buttonStyle
        container.append(myButtonPokeThree)


        myButtonPokeOne.addEventListener('click', () => {
        fetch('https://pokeapi.co/api/v2/pokemon/ditto')
        .then(response => response.json())
        .then(data => {
        console.log(data)
            })
        .catch(error => console.log('Error', error));
          })
        

        myButtonPokeTwo.addEventListener('click', () => {
        fetch('https://pokeapi.co/api/v2/pokemon/eevee')
        .then(response => response.json())
        .then(data => {
        console.log(data)
            })
        .catch(error => console.log('Error', error));
          })

        myButtonPokeThree.addEventListener('click', () => {
        fetch('https://pokeapi.co/api/v2/pokemon/squirtle')
        .then(response => response.json())
        .then(data => {
        console.log(data)
              })
        .catch(error => console.log('Error', error))
        })

 })