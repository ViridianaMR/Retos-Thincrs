const main = () => {

    let option

    do {
        option = prompt('[1]Analizar palabras palindromas \n[2] Salir')


        if (option === '1') {
            const word = prompt('Ingresar palabra')

                    if (word) {
                        function isPalindrome(prompt) {
                            const cleanedWord = prompt.toLowerCase().replace(/[^a-z0-9]/g, '');
                            const reversedWord = cleanedWord.split('').reverse().join('');

                            return cleanedWord === reversedWord;
                        }
                                if (isPalindrome(word)) {
                                        alert('¡Es un palíndromo!');
                                        }else{
                                        alert('No es un palíndromo :(');      
                                        }                 
                                }else{
                                    alert('Ninguna palabara fue ingresada');
                        
                    }}
                    }
            

    while (option !== '2')

   alert('¡Adiós!')
        }
    main()
