const person = {

    name: '',
    gender: '',
    weight: '',
    height: '',
    haveWork: '',
    favoriteColors: []
}

const people = [ ]

const createPerson = (name, gender, weight, height, haveWork, favoriteColors) => { 
    const newPerson = {name, gender, weight, height, haveWork, favoriteColors}
    people.push(newPerson)
    }

const readPeople = (person) => {
    return people.find((person) => person.name)
    }
    
const getAllPeople = () => {
    return people
    }

const deletePerson = (name) => {
    const personToDelete = person.name(personToDelete)
    console.log('Persona a eliminar', personToDelete)
    students.splice(personToDelete)
    }


do {
    option = prompt(`
    [1] Crear un nueva persona
    [2] Personas divididas por género
    [3] Personas divididas por peso
    [4] Personas divididas por altura
    [5] Tener datos de todas las personas
    [6] Salir
    `)
    
switch (option) {
    case '1':
        const name = prompt ('Ingresa el nombre')
        const gender = prompt ('Ingresa el género')
        const weight = prompt ('Ingresa el peso (kg)')
        const height = prompt ('Ingresa la altura (cm)')
        const haveWork = prompt ('Ingresa su trabajo')
        const favoriteColors = prompt ('Ingresa sus colores favoritos separados por coma')
        createPerson(name, gender, weight, height, haveWork, favoriteColors)
        break

    case '2':
        const allFemalePeople = people.filter(person => person.gender === 'mujer');
        console.log('Todas las personas femeninas: ', allFemalePeople);
        const allMalePeople = people.filter(person => person.gender === 'hombre');
        console.log('Todas las personas masculinas: ', allMalePeople);
        break

    case '3':
        const peopleWeightAbove = people.filter(person => person.weight >= 60);
        console.log('Todas las personas que pesen más de 60 kilos: ', peopleWeightAbove);
        const peopleWeightBelow = people.filter(person => person.weight < 60);
        console.log('Todas las personas que pesen menos de 60 kilos: ', peopleWeightBelow);
        break


    case '4':
        const peopleHeightAbove = people.filter(person => person.height >= 150);
        console.log('Todas las personas que midan más de 150 cm: ', peopleHeightAbove);
        const peopleHeightBelow = people.filter(person => person.height < 150);
        console.log('Todas las personas que midan menos de 150 cm: ', peopleHeightBelow);
        break
    
    
    case '5':
        console.log('Todas las personas: ', getAllPeople())
        break
    }

}while (option !== '6')